#include <stdio.h>
#include <stdlib.h>

int main()
{
    char texto[128];
    scanf ("%s", &texto);
    printf ("ingresaste: %s", texto);
    return 0;
}
