#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

int factorial(int );

#endif // FUNCIONES_H_INCLUDED

